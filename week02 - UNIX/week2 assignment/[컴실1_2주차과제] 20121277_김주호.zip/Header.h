#include <stdlib.h>
#include <stdio.h> 

void get_num_of_TestCase(int *t);
void register_TestCase_at_dynamic_array(int* arr_dynamic, int t);
void print_the_numbers(int* ans);


