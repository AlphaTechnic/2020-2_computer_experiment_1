#pragma once

#include "ofMain.h"
#define WIDTH 1024
#define HEIGHT 768

class ofApp : public ofBaseApp {

public:
	void setup();
	void update();
	void draw();
	//void draw_water();

	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y);
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered(int x, int y);
	void mouseExited(int x, int y);
	void windowResized(int w, int h);
	void dragEvent(ofDragInfo dragInfo);
	void gotMessage(ofMessage msg);
	void processOpenFileSelection(ofFileDialogResult openFileResult);

	int num_of_lines, num_of_dots;
	vector<int> lx, ly, dx, dy;
	int draw_flag = 0;
	int water_flag = 0;
	int floor_flag=0;
	int action_flag = 0;
	int target_dot;
	float yval, tmp;
	float newx, newy, endx, endy;
	int i = 0;
};