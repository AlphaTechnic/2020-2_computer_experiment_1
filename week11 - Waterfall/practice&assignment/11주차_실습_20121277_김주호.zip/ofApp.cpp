#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup() {
	ofSetBackgroundAuto(false);
	ofBackground(255);
	ofSetLogLevel(OF_LOG_VERBOSE);
}

//--------------------------------------------------------------
void ofApp::update() {

}

//--------------------------------------------------------------
void ofApp::draw() {
	if (draw_flag) {
		ofClear(255);
		ofSetColor(150, 75, 0); // ���� 
		ofFill(); // �� ä���
		ofSetLineWidth(20); // ���� 20
		ofDrawLine(0, 15, WIDTH, 15);
		ofDrawLine(0, HEIGHT-10, WIDTH, HEIGHT-10);

		for (i = 0; i < num_of_lines * 2; i += 2) { 
			ofSetColor(150, 75, 0); // ���� 
			ofFill(); // �� ä���
			ofSetLineWidth(5); // ���� 5
			ofDrawLine(lx[i], ly[i], lx[i + 1], ly[i + 1]);
		}

		for (i = 0; i < num_of_dots; i++) {
			if (i == target_dot) {
				ofSetColor(255, 0, 0); // ������
			}
			else {
				ofSetColor(0x000000); // ������
			}
			ofDrawCircle(dx[i], dy[i], 10);
		}
		draw_flag = 0;
	}

	if (water_flag) {
		action_flag = 1;
		ofSetColor(0, 0, 150); // �Ķ��� 
		ofFill(); // �� ä���
		ofSetLineWidth(5); // ���� 5
		
		newx = dx[target_dot];
		newy = dy[target_dot];
		while (!floor_flag) {
			yval = HEIGHT - 10;
			floor_flag = 1;
			for (i = 0; i < num_of_lines * 2; i += 2) {
				if ((newx >= lx[i]) && (newx <= lx[i + 1])) {
					tmp = ((float)(ly[i + 1] - ly[i]) / (lx[i + 1] - lx[i])) * (newx - lx[i]) + ly[i];
					if (yval > tmp && tmp > newy) {
						floor_flag = 0;
						yval = tmp;
						endx = (ly[i + 1] > ly[i]) ? lx[i + 1] : lx[i];
						endy = (ly[i + 1] > ly[i]) ? ly[i + 1] : ly[i];
					}
				}
			}
			if (!floor_flag) { // water�� �ٴڿ� ���� ���� �ʾҴٸ�, (yval�� ���ŵǾ��ٸ�,)
				ofDrawLine(newx, newy, newx, yval);
				ofDrawLine(newx, yval, endx, endy);
				newx = endx;
				newy = endy;
			}
			else { // water�� �ٴڿ� ��Ҵٸ�, (yval�� ���ŵ��� �ʾҴٸ�)
				ofDrawLine(newx, newy, newx, HEIGHT-10);
			}
		}
		water_flag = 0;
		floor_flag = 0;
	}
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
	if (key == 'd' || key == 'D') {
		action_flag = 0;
		draw_flag = 1; // draw_flag�� set
		water_flag = 0; // water �׸��� �ʴ´�.
		draw();
	}

	if (key == 's' || key == 'S') {
		draw_flag = 1;
		water_flag = 1; // water_flag set
		draw();
	}

	if (key == 'e' || key == 'E') {
		action_flag = 0;
		draw_flag = 1;
		water_flag = 0;
		draw();
	}

	if (key == OF_KEY_LEFT) {
		ofFill(); // ä���
		ofSetColor(0x000000);
		ofDrawCircle(dx[target_dot], dy[target_dot], 10); // ����������
		target_dot = (target_dot + dx.size() - 1) % dx.size();
		ofSetColor(255, 0, 0); //������
		ofDrawCircle(dx[target_dot], dy[target_dot], 10);
		cout << "Selected Dot coordinate is (" << dx[target_dot] << ", " << dy[target_dot] << ")" << endl;

		if (action_flag) { // ȭ�鿡 water�׸��� �׷����� action�� ������ ��Ȳ�̶��, 
			action_flag = 0;
			draw_flag = 1; // draw_flag�� set
			water_flag = 1; // water �׸���.
			draw();
		}
	}

	if (key == OF_KEY_RIGHT) {
		ofFill();
		ofSetColor(0);
		ofDrawCircle(dx[target_dot], dy[target_dot], 10);
		target_dot = (target_dot + 1) % dx.size(); // 1 ����
		ofSetColor(255, 0, 0); // ������
		ofDrawCircle(dx[target_dot], dy[target_dot], 10);
		cout << "Selected Dot coordinate is (" << dx[target_dot] << ", " << dy[target_dot] << ")" << endl;

		if (action_flag) { // ȭ�鿡 water�׸��� �׷����� action�� ������ ��Ȳ�̶��, 
			action_flag = 0;
			draw_flag = 1; // draw_flag�� set
			water_flag = 1; // water �׸���.
			draw();
		}
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {
	if (key == 'l' || key == 'L') {
		ofFileDialogResult openFileResult = ofSystemLoadDialog("Select an input file");
		if (openFileResult.bSuccess) {
			ofLogVerbose("User selected a file");
			processOpenFileSelection(openFileResult); // ���Ϸκ��� �� �Է¹ޱ� 
		}
		else {
			ofLogVerbose("User hit cancel");
		}
	}
	if (key == 'q' || key == 'Q') {
		lx.clear(); ly.clear();
		vector<int>().swap(lx);
		vector<int>().swap(ly);
		cout << "Memory for line segment has been freed" << endl;
		dx.clear(); dy.clear();
		vector<int>().swap(dx);
		vector<int>().swap(dy);
		cout << "Memory for dot has been freed" << endl;
		ofExit(); // ���α׷� ����
		return;
	}
}


//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}
void ofApp::processOpenFileSelection(ofFileDialogResult openFileResult) {
	ifstream file;
	file.open(openFileResult.getPath()); // �ش� ��ο� �ִ� ���� ����

	int line_or_dot = 0;
	int line_count = 0;
	string line;

	if (!file.is_open()) cout << "file open error" << endl;
	else cout << "We found the target" << endl;

	while (!file.eof()) {
		getline(file, line);
		vector <string> words = ofSplitString(line, " "); // split

		if (words.size() == 1) { // ���� ���� or �� ����
			if (line_or_dot == 0) {
				num_of_lines = atoi(words[0].c_str());
				line_count = num_of_lines;
				cout << "The number of line is: " << num_of_lines << endl;
			}
			else { // ��
				num_of_dots = atoi(words[0].c_str()); // ���� ����
				cout << "The number of dot is: " << num_of_dots << endl;
			}
		}
		else if (words.size() > 1) { // ��ǥ��
			if (line_or_dot == 0) {
				lx.push_back(atoi(words[0].c_str()));
				ly.push_back(atoi(words[1].c_str()));
				lx.push_back(atoi(words[2].c_str()));
				ly.push_back(atoi(words[3].c_str()));

				line_count--;

			}
			else {
				dx.push_back(atoi(words[0].c_str()));
				dy.push_back(atoi(words[1].c_str()));
			}
		}
		if (line_count == 0) {
			line_or_dot = 1;
		}
	}
}